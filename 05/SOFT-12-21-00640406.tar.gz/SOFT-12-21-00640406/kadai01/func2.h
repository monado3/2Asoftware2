#ifndef OPTIMIZE1_FUNC2_H
#define OPTIMIZE1_FUNC2_H

int f_dimension();
double f_value(const double x[]);
void f_gradient(const double x[], double g[]);

#endif
