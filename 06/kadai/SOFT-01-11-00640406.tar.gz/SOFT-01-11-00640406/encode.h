#ifndef HUFFMAN_ENCODE_H
#define HUFFMAN_ENCODE_H

int encode(const char *filename);

#endif
